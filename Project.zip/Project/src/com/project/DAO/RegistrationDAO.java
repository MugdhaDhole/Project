package com.project.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.model.User;

public class RegistrationDAO {
	public boolean register(User user) {
		System.out.println("New User : " + user);

		System.out.println("Start of RegistrationDAO :: register");

		String url = "jdbc:mysql://localhost:3306/test";
		String db_username = "root";
		String db_password = "Whitebox@123";

		Connection con;
		PreparedStatement pstmt;

		String sql = "INSERT INTO User VALUES(?,?,?,?,?)";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, db_username, db_password);
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, user.getId());
			pstmt.setString(2, user.getUsername());
			pstmt.setString(3, user.getPassword());
			pstmt.setInt(4, user.getPhone());
			pstmt.setString(5, user.getAddress());

			int result = pstmt.executeUpdate();

			if (result > 0)
				return true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("End of RegistrationDAO :: register");
		return false;
	}
}
