package com.project.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserDAO {

	public ResultSet getUsers() {

		String url = "jdbc:mysql://localhost:3306/test";
		String db_username = "root";
		String db_password = "Whitebox@123";

		Connection con;
		Statement stmt;
		ResultSet rs = null;
		String sql = "SELECT * FROM User";

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, db_username, db_password);

			stmt = con.createStatement();

			rs = stmt.executeQuery(sql);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;

	}
}