package com.project.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.DAO.RegistrationDAO;
import com.project.model.User;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/registration")
public class Registration extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RegistrationDAO dao;

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		int phone = Integer.parseInt(request.getParameter("phone"));
		String address = request.getParameter("address");
		// Generating UserID
		Random random = new Random();
		int userid = random.nextInt(999);
		// System.out.println(userid);

		User user = new User(userid, username, password, phone, address);

		// System.out.println(username + " " + password + " " + phone + " " + address);
		// System.out.println("New User : " + user);
		// Save user details to Database
		dao = new RegistrationDAO();
		boolean result = dao.register(user);

		if (result) {
			System.out.println("Inserted Successfully");
			response.sendRedirect("home.jsp");
		} else {
			System.err.println("Something went wrong");
			response.sendRedirect("error.jsp");
		}
	}

}
